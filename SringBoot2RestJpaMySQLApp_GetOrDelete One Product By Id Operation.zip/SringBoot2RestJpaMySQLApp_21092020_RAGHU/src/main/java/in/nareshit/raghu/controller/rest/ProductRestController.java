package in.nareshit.raghu.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.service.IProductService;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	@Autowired
	private IProductService service; //HAS-A 

	/**
	 * This operation indicates Read JSON data from 
	 * HTTP Request (Body) and convert into Object
	 * using @RequestBody Annotation.
	 * 
	 * By using service Layer save data to product table.
	 * Returns Response as Entity with 201 CREATED 
	 * Else 500 - INTERNAL SERVER ERROR
	 * 
	 * @param product
	 * @return ResponseEntity<String>
	 */

	@PostMapping("/save")
	public ResponseEntity<String> saveProduct(
			@RequestBody Product product) 
	{
		ResponseEntity<String> resp = null;
		try {
			Integer id = service.saveProduct(product);
			resp = new ResponseEntity<String>(
					"Product '"+id+"' Created", 
					HttpStatus.CREATED); //201-Created
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>(
					"Unable to save Product", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500-ISE
		}
		return resp;
	}

	/**
	 * This operations takes no Input, if you want you can Accept Header (optional) 
	 * for XML Output only. Default Gives JSON Output if data exist,
	 * else returns empty collection like [].
	 * @return ResponseEntity
	 */
	@GetMapping("/all")
	public ResponseEntity<?> getAllProducts() {
		ResponseEntity<?> resp = null;
		try {
			List<Product> list =  service.getAllProduct();
			resp = new ResponseEntity<List<Product>>(
					list,
					HttpStatus.OK);//200-OK
		} catch (Exception e) {
			resp = new ResponseEntity<String>(
					"Unable to save Product", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500-ISE
		}
		return resp;
	}

	/***
	 * Client makes Request using PathVariable.
	 * If given id exist then service returns Product
	 * Else it throws ProductNotFoundException.
	 * 
	 * If Exception Type is ProductNotFound Exception
	 * then re-throw to Exception-Handler.
	 * 
	 * Else create ResponseEntity with 500-Message
	 *  
	 * @param id
	 * @return ResponseEntity
	 */

	@GetMapping("/find/{id}")
	public ResponseEntity<?> getOneProduct(
			@PathVariable Integer id
			)
	{
		ResponseEntity<?> resp = null;
		try {
			Product product = service.getOneProduct(id);
			resp = new ResponseEntity<Product>(
							product, 
							HttpStatus.OK);
		} catch(ProductNotFoundException  pne) {
			throw pne; // re-throw exception
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>(
					"Unable to find Product", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500-ISE
		}  
		return resp;
	}

	
	/***
	 * Client makes Request using PathVariable.
	 * If given id exist then service delete product
	 * Else it throws ProductNotFoundException.
	 * 
	 * If Exception Type is ProductNotFound Exception
	 * then re-throw to Exception-Handler.
	 * 
	 * Else create ResponseEntity with 500-Message
	 *  
	 * @param id
	 * @return ResponseEntity
	 */
	
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> deleteProduct(
			@PathVariable Integer id
			) 
	{
		ResponseEntity<String> resp = null;
		try {
			service.deleteProduct(id);
			resp = new ResponseEntity<String>(
					"Product '"+id+"' deleted", HttpStatus.OK);
		} catch(ProductNotFoundException pne) {
			throw pne; // re-throw exception to handler
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>(
					"Unable to Delete Product", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500-ISE
		}
		
		return resp;
	}
	
	
    
}
